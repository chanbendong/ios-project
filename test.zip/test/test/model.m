//
//  model.m
//  test
//
//  Created by zjdg－iOS on 16/5/4.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import "model.h"

@implementation model

@end
