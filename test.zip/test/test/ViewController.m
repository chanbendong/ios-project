//
//  ViewController.m
//  test
//
//  Created by zjdg－iOS on 16/4/18.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "FirstViewController.h"
@interface ViewController ()

@property (nonatomic,strong) UIView *bgView;
@property (nonatomic,strong) UITextField *tf;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(30, 20, 100, 50);
    button.backgroundColor = [UIColor redColor];
    [button addTarget:self action:@selector(hehe:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    self.view.backgroundColor = [UIColor greenColor];
    
    
    //    self.tf = [[UITextField alloc] initWithFrame:CGRectMake(20, 50, 300, 50)];
    //    self.tf.borderStyle = UITextBorderStyleLine;
    //    [self.view addSubview:self.tf];
    
    
}

- (void)hehe:(UIButton *)sender{
    NSLog(@"点击");
    FirstViewController *vc = [[FirstViewController alloc] init];
    [self presentViewController:vc animated:YES completion:nil];

}







@end