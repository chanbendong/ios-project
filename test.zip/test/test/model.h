//
//  model.h
//  test
//
//  Created by zjdg－iOS on 16/5/4.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface model : NSObject
@property (nonatomic , copy) NSString *name;

@end
