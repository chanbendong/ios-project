//
//  FirstViewController.h
//  test
//
//  Created by zjdg－iOS on 16/5/4.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "model.h"

@interface FirstViewController : UIViewController

@property (nonatomic, strong) model *addresModel;

@end
