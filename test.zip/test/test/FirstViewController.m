//
//  FirstViewController.m
//  test
//
//  Created by zjdg－iOS on 16/5/4.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import "FirstViewController.h"
#import "view.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.addresModel = [[model alloc] init];
    
    view *VC = [[view alloc] init];
    VC.frame = CGRectMake(0 , 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [VC upDataView:self.addresModel];
    [self.view addSubview:VC];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(200, 200, 200, 200)];
    btn.backgroundColor = [UIColor grayColor];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

-(void)btnClick{
    NSLog(@"%@",self.addresModel.name);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
