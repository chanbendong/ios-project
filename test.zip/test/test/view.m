//
//  view.m
//  test
//
//  Created by zjdg－iOS on 16/5/4.
//  Copyright © 2016年 zjdg－iOS. All rights reserved.
//

#import "view.h"

@interface view  ()<UITextFieldDelegate>

@property (nonatomic , strong) model *addressInfoModel;


@end

@implementation view

-(instancetype)init{
    return [self initWithFrame:[UIScreen mainScreen].bounds];
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    UITextField *addressDetailField = [[UITextField alloc] initWithFrame:CGRectMake(100, 100, 100, 30)];
    addressDetailField.delegate = self;
    [addressDetailField addTarget:self action:@selector(textFieldEditChanged:) forControlEvents:UIControlEventEditingChanged];
    addressDetailField.placeholder = @"例:2号楼-1101室";
    addressDetailField.font = [UIFont systemFontOfSize:14];
    [self addSubview:addressDetailField];

    
    return self;
}

- (void)textFieldEditChanged:(UITextField *)textField
{
    _addressInfoModel.name = textField.text;
}

-(void)upDataView:(model *)AddressInfoModel{
    _addressInfoModel = AddressInfoModel;
 
    
}

@end
